<?php
// Heading
$_['heading_title']           = 'Dummy Tool';
$_['version']                 = ' <span style="color:#666; font-size: 11px; font-weight:normal;">(версия: %s)</span>';

// Text 
$_['text_octeam_toolset']     = 'Инструменты';
$_['text_success']            = 'Настройки инструмента "Dummy Tool" обновлены!';
$_['text_dummy']              = '<a onclick="window.open(\'http://myopencart.ru/\');"><img src="view/image/octeam/octeam.png" alt="OC Team" title="OC Team" style="border: 1px solid #EEEEEE;" height="25px" /><img src="view/image/octeam/tool/dummy.png" alt="Dummy" title="Dummy" style="border: 1px solid #EEEEEE;" height="25px" /></a>';
$_['text_description']        = 'This is a dummy description of dummy tool. It shoud NOT be too long.';

// Error
$_['error_permission']        = 'У вас нет прав для изменения инструмента "Dummy"!';
 
?>