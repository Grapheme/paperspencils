<?php
// Text
$_['text_footer'] = '<a href="http://myopencart.ru">ocStore</a> &copy; 2009-' . date('Y') . ' Все права защищены.<br />Версия %s';
?>