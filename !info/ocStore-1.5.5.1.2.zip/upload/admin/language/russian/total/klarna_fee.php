<?php
// Heading
$_['heading_title']    = 'Взнос Klarna';

// Text
$_['text_total']       = 'Все заказы';
$_['text_success']     = 'Настройки модуля обновлены!';

// Entry
$_['entry_total']      = 'Общая сумма заказа:';
$_['entry_fee']        = 'Взнос:';
$_['entry_tax_class']  = 'Налоговый класс:';
$_['entry_status']     = 'Статус:';
$_['entry_sort_order'] = 'Порядок сортировки:';

// Error
$_['error_permission'] = 'У Вас нет прав для управления взносом!';
?>