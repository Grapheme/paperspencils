<?php
// Heading 
$_['heading_title']    = 'Extension Manager';

// Text
$_['text_success']     = 'Success: You have installed your extension!';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify extension manager!';
$_['error_upload']     = 'Upload required!';
$_['error_filetype']   = 'Invalid file type!';
?>